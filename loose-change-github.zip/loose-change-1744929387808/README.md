# Loose Change

A web application that translates billionaire financial transactions into relatable financial perspectives for average-income users, helping people understand wealth scale through interactive visualizations.

> **Curious how this webapp was made?** We built it using a no-code conversation with [Replit AI](https://replit.com/refer/112749825).

## Live Demo

Try the application here: [Loose Change on Replit](https://wealth-compare-112749825.replit.app/)

## Features

- Interactive wealth comparison calculator
- Billionaire data from Gapminder dataset (2022)
- Real-time currency conversion between EUR and USD
- Mobile-optimized interface with responsive design
- Contextual examples to understand large numbers

## Technologies Used

- **Frontend**: React with TypeScript, Tailwind CSS, shadcn/ui components
- **Backend**: Node.js with Express
- **Database**: PostgreSQL with Drizzle ORM
- **State Management**: React Query, React Hook Form
- **Data Visualization**: Recharts
- **Styling**: Tailwind CSS with custom theme

## Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Set up the database (see Database Setup below)
4. Start the development server with `npm run dev`

## Database Setup

The application uses PostgreSQL. Make sure to have a running PostgreSQL instance and set the following environment variables:

```
DATABASE_URL=postgres://username:password@localhost:5432/loose_change
```

Initialize the database with:

```
npm run db:push
```

## Deployment

The application can be deployed to any platform that supports Node.js and PostgreSQL.

## Privacy Notice

This application does not store any personal data, including income information. All calculations are performed client-side in your browser, and sensitive inputs like salary information are never stored or transmitted to our servers.

## Data Sources

- Billionaire data from Gapminder Billionaires dataset (2022)
- Currency exchange rates updated daily

## Contributing

Feedback and contributions are welcome! Please feel free to submit a pull request.

## License

MIT