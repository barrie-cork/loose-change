export default function Footer() {
  return (
    <footer className="bg-[#161B22] text-[#C9D1D9] py-6 mt-2 border-t border-[#30363D]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center">
          <div className="flex flex-wrap items-center">
            <p className="text-xs text-[#8B949E]">
              &copy; {new Date().getFullYear()} Loose Change. All rights reserved.
            </p>
            <div className="mx-2 text-xs text-[#8B949E]">•</div>
            <div className="flex items-center flex-wrap">
              <p className="text-xs text-[#8B949E] mr-1">
                Made with 
              </p>
              <a 
                href="https://replit.com/refer/112749825" 
                target="_blank" 
                rel="noopener noreferrer"
                className="accent-gradient text-white text-xs px-1.5 py-0.5 rounded-md font-medium hover:opacity-90 transition-all hover:shadow-lg hover:shadow-orange-500/20"
              >
                Replit AI
              </a>
            </div>
          </div>
          <div className="mt-4 md:mt-0">
            <span className="text-xs text-[#8B949E]">
              Privacy-focused: No user data is ever saved or tracked.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
