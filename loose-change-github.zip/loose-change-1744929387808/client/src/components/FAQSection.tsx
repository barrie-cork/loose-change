import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQSection() {
  return (
    <section id="faq" className="mt-12 bg-[#0D1117] border border-[#30363D] rounded-lg p-6">
      <h2 className="text-xl font-semibold text-[#C9D1D9] mb-6">Frequently asked questions</h2>
      
      <Accordion type="multiple" className="space-y-2">
        <AccordionItem value="item-1" className="border-b border-[#30363D]">
          <AccordionTrigger className="text-base font-medium text-[#C9D1D9] py-3 hover:no-underline">
            How are these calculations made?
          </AccordionTrigger>
          <AccordionContent className="text-sm text-[#8B949E] leading-relaxed pb-4">
            We calculate the proportion of a billionaire's net worth that a transaction represents, then apply that same proportion to an annual income. This provides a relatable comparison of what that expense would feel like to someone with that income.
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-2" className="border-b border-[#30363D]">
          <AccordionTrigger className="text-base font-medium text-[#C9D1D9] py-3 hover:no-underline">
            Where does the billionaire data come from?
          </AccordionTrigger>
          <AccordionContent className="text-sm text-[#8B949E] leading-relaxed pb-4">
            We source our data from the Gapminder billionaires dataset (2022) and public financial reporting platforms. 
            For more details on our data sources and methodology, visit our <a href="https://github.com/barrie-cork/loose-change/discussions/1" target="_blank" rel="noopener noreferrer" className="text-[#2F81F7] hover:text-[#57A3F7] hover:underline transition-colors">GitHub repository</a>.
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-3" className="border-b border-[#30363D]">
          <AccordionTrigger className="text-base font-medium text-[#C9D1D9] py-3 hover:no-underline">
            Is this tool politically biased?
          </AccordionTrigger>
          <AccordionContent className="text-sm text-[#8B949E] leading-relaxed pb-4">
            No. Loose Change simply provides mathematical comparisons based on publicly available financial data. We don't make judgments about wealth or suggest policy positions. Our goal is to help people understand large financial numbers in relatable terms.
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-4" className="border-b border-[#30363D]">
          <AccordionTrigger className="text-base font-medium text-[#C9D1D9] py-3 hover:no-underline">
            Can I use these comparisons for research or journalism?
          </AccordionTrigger>
          <AccordionContent className="text-sm text-[#8B949E] leading-relaxed pb-4">
            Absolutely! We encourage using these comparisons for educational purposes. Please credit "Loose Change" when using our calculations in published work.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </section>
  );
}
