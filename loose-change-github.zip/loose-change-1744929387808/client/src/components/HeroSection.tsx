export default function HeroSection() {
  return (
    <section className="mb-8 text-center">
      <p className="text-base text-secondary-600 max-w-3xl mx-auto text-justify md:text-center">
        See what billionaire philanthropic donations (excluding tax write-off advantages) and fines would feel like for someone with a normal salary income. A €10 million philanthropic gift? A €100 million regulatory fine? Translate it to everyday financial reality.
      </p>
    </section>
  );
}
