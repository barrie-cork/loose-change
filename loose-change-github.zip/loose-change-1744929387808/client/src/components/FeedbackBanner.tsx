import { useState } from "react";
import { InfoIcon, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function FeedbackBanner() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <section className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4">
      <Collapsible open={isOpen} onOpenChange={setIsOpen} className="w-full">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-[#2F81F7] flex-shrink-0">
              <InfoIcon size={20} />
            </div>
            <h3 className="text-lg font-medium text-[#C9D1D9]">
              Call for expert feedback
            </h3>
          </div>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="p-1 h-auto text-[#8B949E] hover:text-[#C9D1D9]">
              {isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              <span className="sr-only">{isOpen ? "Close" : "Open"}</span>
            </Button>
          </CollapsibleTrigger>
        </div>
        
        <CollapsibleContent className="mt-3">
          <div className="pl-7"> {/* Align with the header text */}
            <p className="text-[#8B949E] mb-3 leading-relaxed">
              This application uses a simplified approach to wealth comparison. We acknowledge 
              the limitations of our current methodology and invite economists, financial experts, 
              and researchers to provide constructive feedback and suggestions for improvement through 
              our GitHub Discussion forum.
            </p>
            <p className="text-[#8B949E] text-sm mb-4 leading-relaxed">
              Our current model uses a linear comparison between net worth and annual income, 
              which doesn't capture many economic nuances such as diminishing marginal utility, 
              wealth velocity, or privilege accumulation effects. We are committed to evolving 
              this tool to better represent wealth inequality in meaningful ways, and your input is invaluable.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button 
                variant="default" 
                className="bg-[#2F81F7] text-white border-none hover:bg-[#57A3F7] transition-colors"
                onClick={() => window.open("https://github.com/barrie-cork/loose-change/discussions/1", "_blank")}
              >
                Join the discussion
              </Button>
              <Button 
                variant="outline" 
                className="text-[#C9D1D9] border-[#30363D] hover:bg-[#161B22] hover:text-[#C9D1D9] hover:border-[#30363D] transition-colors"
                onClick={() => window.open("https://github.com/barrie-cork/loose-change/discussions/1", "_blank")}
              >
                View methodology
              </Button>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </section>
  );
}