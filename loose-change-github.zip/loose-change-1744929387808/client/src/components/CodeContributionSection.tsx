import { useState } from "react";
import { 
  Code2Icon, 
  GithubIcon, 
  ChevronDown, 
  ChevronUp, 
  ExternalLinkIcon, 
  CodeIcon,
  BookOpenIcon
} from "lucide-react";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";

export default function CodeContributionSection() {
  return (
    <section className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4 mb-6">
      <Accordion type="single" collapsible className="w-full">
        {/* Built with Replit AI Section */}
        <AccordionItem value="built-with-replit" className="border-b border-[#30363D] pb-2">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center text-[#C9D1D9]">
              <CodeIcon className="w-5 h-5 mr-2 text-[#2F81F7]" />
              <h3 className="text-base font-medium">Built with Replit AI</h3>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="pl-7 text-[#8B949E] mt-2">
              <p className="leading-relaxed text-sm">
                This web application was built entirely through a conversation with Replit AI, 
                without writing a single line of code manually. The AI generated the complete frontend 
                and backend, implemented the financial comparison logic, and designed the responsive UI.
              </p>
              <div className="mt-3">
                <a 
                  href="https://replit.com/refer/112749825" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-[#2F81F7] hover:text-[#57A3F7] hover:underline transition-colors"
                >
                  <span>Learn more about Replit AI</span>
                  <ExternalLinkIcon className="w-3.5 h-3.5 ml-1" />
                </a>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* GitHub Repository Section */}
        <AccordionItem value="github-repo" className="border-b border-[#30363D] pb-2">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center text-[#C9D1D9]">
              <GithubIcon className="w-5 h-5 mr-2 text-[#2F81F7]" />
              <h3 className="text-base font-medium">GitHub Repository</h3>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="pl-7 text-[#8B949E] mt-2">
              <p className="leading-relaxed text-sm">
                The entire codebase for this project is open source and available on GitHub. 
                We welcome contributions, bug reports, and feature requests from developers 
                interested in improving this tool.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a 
                  href="https://github.com/barrie-cork/loose-change" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-[#21262D] text-[#C9D1D9] px-3 py-1.5 rounded text-sm hover:bg-[#30363D] transition-colors"
                >
                  <GithubIcon className="w-4 h-4 mr-1.5" />
                  <span>View Repository</span>
                </a>
                <a 
                  href="/api/download-backup" 
                  className="inline-flex items-center bg-[#2F81F7] text-white px-3 py-1.5 rounded text-sm hover:bg-[#57A3F7] transition-colors"
                >
                  <Code2Icon className="w-4 h-4 mr-1.5" />
                  <span>Download Source Code</span>
                </a>
                <a 
                  href="https://github.com/barrie-cork/loose-change/archive/refs/heads/main.zip" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-[#30363D] text-[#8B949E] px-3 py-1.5 rounded text-sm hover:bg-[#21262D] hover:text-[#C9D1D9] transition-colors"
                >
                  <span>Download from GitHub</span>
                </a>
                <a 
                  href="https://github.com/barrie-cork/loose-change/issues/new" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-[#21262D] text-[#C9D1D9] px-3 py-1.5 rounded text-sm hover:bg-[#30363D] transition-colors"
                >
                  <span>Report Issue</span>
                </a>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Methodology Discussion Section */}
        <AccordionItem value="methodology" className="border-b-0">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center text-[#C9D1D9]">
              <BookOpenIcon className="w-5 h-5 mr-2 text-[#2F81F7]" />
              <h3 className="text-base font-medium">Methodological Discussions</h3>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="pl-7 text-[#8B949E] mt-2">
              <p className="leading-relaxed text-sm">
                Our wealth comparison model uses a proportional calculation based on the formula:
              </p>
              <div className="bg-[#161B22] p-3 rounded-md my-2 font-mono text-xs border border-[#30363D]">
                user_equivalent = (billionaire_transaction / billionaire_net_worth) * user_annual_income
              </div>
              <p className="leading-relaxed text-sm mt-2">
                We invite economists, researchers, and financial experts to discuss methodological improvements. 
                Some topics for consideration include:
              </p>
              <ul className="list-disc pl-5 mt-2 text-sm space-y-1.5">
                <li>Adjusting for diminishing marginal utility of wealth</li>
                <li>Accounting for differences between income and wealth-based calculations</li>
                <li>Incorporating purchasing power parity across different economies</li>
                <li>Developing models that reflect liquidity constraints of billionaire wealth</li>
                <li>Including tax implications in the comparison framework</li>
                <li>Time-based models (hours worked to earn equivalent amounts)</li>
              </ul>
              <div className="mt-4 space-y-3">
                <a 
                  href="https://github.com/barrie-cork/loose-change/discussions/1" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-[#2F81F7] hover:text-[#57A3F7] hover:underline transition-colors"
                >
                  <span>Join the methodological discussion forum</span>
                  <ExternalLinkIcon className="w-3.5 h-3.5 ml-1" />
                </a>
                <p className="text-xs text-[#8B949E] italic">
                  We're particularly interested in methodologies that help contextualize extreme wealth in ways that are 
                  mathematically sound while remaining accessible to general audiences.
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </section>
  );
}