import { useEffect, useState, useRef } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Check, ChevronsUpDown, DollarSign, CreditCard, Search, ExternalLink } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn, parseCurrencyInput } from "@/lib/utils";
import { Billionaire, ComparisonInput, ComparisonResult, Currency } from "@/types";

// Form validation schema
const formSchema = z.object({
  billionaireId: z.number({
    required_error: "Please select a billionaire",
  }),
  customNetWorth: z.string().optional(),
  transactionAmount: z.string().min(1, "Please enter an amount"),
  transactionType: z.string(),
  userIncome: z.string().min(1, "Please enter an annual income"),
  currency: z.enum(["USD", "EUR"] as const).default("EUR"),
});

interface CalculatorProps {
  onCalculationComplete: (result: ComparisonResult) => void;
}

export default function Calculator({ onCalculationComplete }: CalculatorProps) {
  const [billionaires, setBillionaires] = useState<Billionaire[]>([]);
  const [filteredBillionaires, setFilteredBillionaires] = useState<Billionaire[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [showCustomNetWorth, setShowCustomNetWorth] = useState(false);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    perPage: 100,
    hasMore: false
  });
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      billionaireId: 0,
      customNetWorth: "",
      transactionAmount: "",
      transactionType: "Philanthropic Donation",
      userIncome: "",
      currency: "EUR",
    },
  });

  const [sortOptions, setSortOptions] = useState({
    sortBy: 'netWorth',
    sortOrder: 'desc' as 'asc' | 'desc'
  });

  // Function to fetch billionaires with pagination, sorting, and searching
  const fetchBillionaires = async (page = 1, limit = 100, sort = sortOptions, search = '') => {
    try {
      const { sortBy, sortOrder } = sort;
      const searchParam = search ? `&search=${encodeURIComponent(search)}` : '';
      const response = await fetch(`/api/billionaires?page=${page}&limit=${limit}&sortBy=${sortBy}&sortOrder=${sortOrder}${searchParam}`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch billionaires data");
      }
      
      const responseData = await response.json();
      
      // Extract the billionaires array and pagination info from the response
      const billionairesData = responseData.data || [];
      const meta = responseData.meta || { 
        currentPage: 1, 
        totalPages: 1, 
        totalCount: billionairesData.length,
        perPage: limit 
      };
      
      return { 
        billionaires: billionairesData, 
        pagination: {
          currentPage: meta.currentPage,
          totalPages: meta.totalPages,
          perPage: meta.perPage,
          hasMore: meta.currentPage < meta.totalPages
        }
      };
    } catch (error) {
      console.error("Error fetching billionaires:", error);
      toast({
        title: "Error fetching billionaires",
        description: "Could not load billionaire data. Please try again later.",
        variant: "destructive",
      });
      return { billionaires: [], pagination: { currentPage: 1, totalPages: 1, perPage: 100, hasMore: false } };
    }
  };
  
  // Function to change the sort order of billionaires
  const changeSortOrder = async (sortBy: string, sortOrder: 'asc' | 'desc') => {
    const newSortOptions = { sortBy, sortOrder };
    setSortOptions(newSortOptions);
    
    // Reset billionaires list and fetch with new sort options
    setBillionaires([]);
    const result = await fetchBillionaires(1, 100, newSortOptions);
    setBillionaires(result.billionaires);
    setPagination(result.pagination);
  };

  // Load more billionaires when needed
  const loadMoreBillionaires = async () => {
    if (pagination.hasMore && !isLoadingMore) {
      setIsLoadingMore(true);
      try {
        const nextPage = pagination.currentPage + 1;
        const searchValue = searchQuery.trim();
        
        // Pass the search query if we're in search mode
        const result = searchValue 
          ? await fetchBillionaires(nextPage, 100, sortOptions, searchValue)
          : await fetchBillionaires(nextPage, 100, sortOptions);
        
        // Append new billionaires to the existing list
        setBillionaires(prev => [...prev, ...result.billionaires]);
        setPagination(result.pagination);
        
        // Also update filtered billionaires if we're searching
        if (searchValue) {
          setFilteredBillionaires(prev => [...prev, ...result.billionaires]);
        }
      } catch (error) {
        console.error("Error loading more billionaires:", error);
      } finally {
        setIsLoadingMore(false);
      }
    }
  };

  // Debounce search handler
  const searchTimeout = useRef<NodeJS.Timeout | null>(null);
  
  // Function to handle search input changes with debounce
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    setIsSearching(value.trim() !== '');
    
    // Clear any existing timeout
    if (searchTimeout.current) {
      clearTimeout(searchTimeout.current);
    }
    
    // Set a timeout to execute the search
    searchTimeout.current = setTimeout(async () => {
      if (value.trim() === '') {
        // If search is cleared, load initial billionaires
        const result = await fetchBillionaires(1, 100, sortOptions);
        setBillionaires(result.billionaires);
        setFilteredBillionaires(result.billionaires);
        setPagination(result.pagination);
      } else {
        // Execute server-side search
        setIsLoading(true);
        try {
          const result = await fetchBillionaires(1, 100, sortOptions, value.trim());
          setFilteredBillionaires(result.billionaires);
          setPagination({
            ...result.pagination,
            // Only show hasMore if we're not searching
            hasMore: value.trim() === '' ? result.pagination.hasMore : false
          });
        } catch (error) {
          console.error("Error during search:", error);
        } finally {
          setIsLoading(false);
        }
      }
    }, 300); // 300ms debounce
  };

  // Fetch initial billionaires on component mount
  useEffect(() => {
    const loadInitialBillionaires = async () => {
      const result = await fetchBillionaires();
      setBillionaires(result.billionaires);
      setFilteredBillionaires(result.billionaires);
      setPagination(result.pagination);
    };

    loadInitialBillionaires();
  }, [toast]);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsLoading(true);
    try {
      // Parse string values to numbers
      const transactionAmount = parseCurrencyInput(values.transactionAmount);
      const userIncome = parseCurrencyInput(values.userIncome);
      const customNetWorth = values.customNetWorth ? parseCurrencyInput(values.customNetWorth) : undefined;

      if (isNaN(transactionAmount) || transactionAmount <= 0) {
        throw new Error("Please enter a valid transaction amount");
      }

      if (isNaN(userIncome) || userIncome <= 0) {
        throw new Error("Please enter a valid annual income");
      }

      if (customNetWorth !== undefined && (isNaN(customNetWorth) || customNetWorth <= 0)) {
        throw new Error("Please enter a valid net worth amount or leave it blank to use default");
      }

      const calculationData: ComparisonInput = {
        billionaireId: values.billionaireId,
        customNetWorth,
        transactionAmount,
        transactionType: values.transactionType,
        userIncome,
        currency: values.currency,
      };

      const response = await apiRequest("POST", "/api/calculate", calculationData);
      const result: ComparisonResult = await response.json();
      
      onCalculationComplete(result);
    } catch (error) {
      console.error("Calculation error:", error);
      toast({
        title: "Calculation Error",
        description: error instanceof Error ? error.message : "Failed to calculate comparison",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Format on blur - ensures proper number format when focus is removed
  const formatCurrencyInput = (e: React.FocusEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9.]/g, "");
    if (value && !isNaN(parseFloat(value))) {
      e.target.value = new Intl.NumberFormat("en-US").format(parseFloat(value));
    }
  };
  
  // Get currency symbol based on selected currency
  const getCurrencySymbol = (currency: string) => {
    return currency === "USD" ? "$" : "€";
  };

  // Format as the user types - adds commas for better readability
  const handleNumberInputChange = (e: React.ChangeEvent<HTMLInputElement>, onChange: (...event: any[]) => void) => {
    // Store cursor position
    const cursorPosition = e.target.selectionStart;
    const inputValue = e.target.value;
    
    // Remove all non-numeric characters except dots
    let sanitizedValue = inputValue.replace(/[^0-9.]/g, "");
    
    // Ensure only one decimal point is allowed
    const parts = sanitizedValue.split('.');
    if (parts.length > 2) {
      sanitizedValue = parts[0] + '.' + parts.slice(1).join('');
    }
    
    // Skip formatting if empty or just a decimal point
    if (!sanitizedValue || sanitizedValue === '.') {
      onChange(sanitizedValue);
      return;
    }
    
    // Format with commas
    let formattedValue;
    if (sanitizedValue.includes('.')) {
      const [integerPart, decimalPart] = sanitizedValue.split('.');
      formattedValue = new Intl.NumberFormat("en-US").format(Number(integerPart)) + '.' + decimalPart;
    } else {
      formattedValue = new Intl.NumberFormat("en-US").format(Number(sanitizedValue));
    }
    
    // Calculate new cursor position
    const inputLength = inputValue.length;
    const newInputLength = formattedValue.length;
    const lengthDifference = newInputLength - inputLength;
    
    // Update the value
    onChange(formattedValue);
    
    // Set the cursor position after the component has been re-rendered
    setTimeout(() => {
      if (cursorPosition !== null) {
        // Adjust the cursor position based on how many commas were added/removed
        const newPosition = Math.min(Math.max(cursorPosition + lengthDifference, 0), newInputLength);
        e.target.setSelectionRange(newPosition, newPosition);
      }
    }, 0);
  };

  return (
    <section className="lg:col-span-5 bg-[#0D1117] rounded-lg border border-[#30363D] p-6">
      <h2 className="text-2xl font-bold text-[#C9D1D9] mb-6">
        Wealth comparison calculator
      </h2>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* STEP 1: Currency Selection */}
          <div className="p-4 border border-[#30363D] bg-[#161B22] rounded-lg">
            <div className="text-sm font-bold text-[#C9D1D9] mb-3">Step 1: Select currency</div>
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-[#8B949E]">
                    Currency
                  </FormLabel>
                  <Select
                    onValueChange={(value) => {
                      field.onChange(value);
                      // Force re-render when currency changes
                      setTimeout(() => form.trigger("userIncome"), 0);
                    }}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="flex items-center">
                        <span className="mr-2">
                          {field.value === "USD" ? (
                            <DollarSign className="h-4 w-4 text-green-600" />
                          ) : (
                            <CreditCard className="h-4 w-4 text-blue-600" />
                          )}
                        </span>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="USD" className="flex items-center">
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-2 text-green-600" />
                          <span>USD (US Dollar)</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="EUR" className="flex items-center">
                        <div className="flex items-center">
                          <CreditCard className="h-4 w-4 mr-2 text-blue-600" />
                          <span>EUR (Euro)</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="mt-1 text-xs text-[#8B949E]">
                    Exchange rates are updated daily
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* STEP 2: Billionaire Selection */}
          <div className="p-4 border border-[#30363D] bg-[#161B22] rounded-lg">
            <div className="text-sm font-bold text-[#C9D1D9] mb-3">Step 2: Select billionaire</div>
            <FormField
              control={form.control}
              name="billionaireId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-[#8B949E]">
                    Choose a billionaire
                  </FormLabel>
                  <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          className={cn(
                            "w-full justify-between",
                            !field.value && "text-muted-foreground"
                          )}
                          onClick={() => setIsPopoverOpen(!isPopoverOpen)}
                        >
                          {field.value
                            ? billionaires.find(
                                (billionaire) => billionaire.id === field.value
                              )?.name || 
                              filteredBillionaires.find(
                                (billionaire) => billionaire.id === field.value
                              )?.name ||
                              "Select a billionaire"
                            : "Select a billionaire"}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <Command>
                        <CommandInput 
                          placeholder="Search for billionaire..." 
                          value={searchQuery}
                          onValueChange={handleSearchChange}
                          className="h-9"
                        />
                        <CommandList>
                          <CommandEmpty>
                            {isSearching ? (
                              <div className="py-6 text-center text-sm">
                                No billionaires found with that name
                              </div>
                            ) : (
                              <div className="py-6 text-center text-sm">
                                No billionaires loaded
                              </div>
                            )}
                          </CommandEmpty>
                          <CommandGroup>
                            {isSearching
                              ? filteredBillionaires.map((billionaire) => (
                                  <CommandItem
                                    key={billionaire.id}
                                    value={billionaire.name}
                                    className="text-sm"
                                    onSelect={() => {
                                      form.setValue("billionaireId", billionaire.id);
                                      setIsPopoverOpen(false);
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        billionaire.id === field.value
                                          ? "opacity-100"
                                          : "opacity-0"
                                      )}
                                    />
                                    <div className="flex justify-between w-full">
                                      <span>{billionaire.name}</span>
                                      <span className="text-secondary-500">
                                        {getCurrencySymbol(form.getValues().currency)}
                                        {typeof billionaire.netWorth === 'number' 
                                          ? new Intl.NumberFormat('en-US', { 
                                              notation: 'compact', 
                                              maximumFractionDigits: 1 
                                            }).format(billionaire.netWorth) 
                                          : billionaire.netWorth}
                                      </span>
                                    </div>
                                  </CommandItem>
                                ))
                              : billionaires.map((billionaire) => (
                                  <CommandItem
                                    key={billionaire.id}
                                    value={billionaire.name}
                                    className="text-sm"
                                    onSelect={() => {
                                      form.setValue("billionaireId", billionaire.id);
                                      setIsPopoverOpen(false);
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        billionaire.id === field.value
                                          ? "opacity-100"
                                          : "opacity-0"
                                      )}
                                    />
                                    <div className="flex justify-between w-full">
                                      <span>{billionaire.name}</span>
                                      <span className="text-secondary-500">
                                        {getCurrencySymbol(form.getValues().currency)}
                                        {typeof billionaire.netWorth === 'number' 
                                          ? new Intl.NumberFormat('en-US', { 
                                              notation: 'compact', 
                                              maximumFractionDigits: 1 
                                            }).format(billionaire.netWorth) 
                                          : billionaire.netWorth}
                                      </span>
                                    </div>
                                  </CommandItem>
                                ))}
                          </CommandGroup>
                          {pagination.hasMore && !isSearching && (
                            <>
                              <CommandSeparator />
                              <div 
                                className="py-2 text-center text-sm text-primary cursor-pointer hover:bg-secondary-100"
                                onClick={loadMoreBillionaires}
                              >
                                {isLoadingMore ? "Loading more..." : "Load more billionaires..."}
                              </div>
                            </>
                          )}
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <p className="mt-1 text-xs text-[#8B949E]">
                    Net worth data from the Gapminder Billionaires dataset (2022).
                    <br/><strong className="text-[#C9D1D9] text-base font-bold">OR</strong>
                  </p>
                  <div className="mt-1 max-w-xs sm:max-w-sm">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="text-xs flex items-start border-[#30363D] bg-[#21262D] text-[#C9D1D9] hover:bg-[#30363D] whitespace-normal h-auto py-2"
                      onClick={() => {
                        window.open("https://www.forbes.com/real-time-billionaires/", "_blank");
                        setShowCustomNetWorth(true);
                      }}
                    >
                      <ExternalLink className="h-3 w-3 mr-1 mt-0.5 flex-shrink-0" />
                      <span>Check Forbes Wealth Index for up-to-date data</span>
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Custom Net Worth Field - Only shown after clicking Forbes link */}
            {showCustomNetWorth && (
              <FormField
                control={form.control}
                name="customNetWorth"
                render={({ field }) => (
                  <FormItem className="mt-4">
                    <FormLabel className="text-sm font-medium text-[#8B949E]">
                      Custom net worth (optional)
                    </FormLabel>
                    <div className="mt-1 relative rounded-md">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-secondary-500">
                        {getCurrencySymbol(form.getValues().currency)}
                      </span>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g., 250,000,000,000"
                          className="pl-7"
                          inputMode="numeric"
                          onChange={(e) => handleNumberInputChange(e, field.onChange)}
                          onBlur={(e) => {
                            formatCurrencyInput(e);
                            field.onBlur();
                          }}
                        />
                      </FormControl>
                    </div>
                    <p className="mt-1 text-xs text-[#8B949E]">
                      Enter updated net worth if you have more recent data from Forbes or other sources
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
          </div>

          {/* STEP 3: Transaction Details */}
          <div className="p-4 border border-[#30363D] bg-[#161B22] rounded-lg">
            <div className="text-sm font-bold text-[#C9D1D9] mb-3">Step 3: Enter transaction details</div>
            
            <FormField
              control={form.control}
              name="transactionAmount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-[#8B949E] leading-tight">
                    Billionaire's transaction amount
                  </FormLabel>
                  <div className="mt-1 relative rounded-md">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-secondary-500">
                      {getCurrencySymbol(form.getValues().currency)}
                    </span>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="10,000,000"
                        className="pl-7"
                        inputMode="numeric"
                        onChange={(e) => handleNumberInputChange(e, field.onChange)}
                        onBlur={(e) => {
                          formatCurrencyInput(e);
                          field.onBlur();
                        }}
                      />
                    </FormControl>
                  </div>
                  <p className="mt-1 text-xs text-[#8B949E] leading-relaxed whitespace-normal">
                    E.g. {getCurrencySymbol(form.getValues().currency)}10M donation, {getCurrencySymbol(form.getValues().currency)}50M fine, etc.
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Transaction Type */}
            <FormField
              control={form.control}
              name="transactionType"
              render={({ field }) => (
                <FormItem className="mt-4">
                  <FormLabel className="text-sm font-medium text-[#8B949E] leading-tight">
                    Transaction type
                  </FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="whitespace-normal h-auto leading-tight py-2 text-left">
                        <SelectValue placeholder="Select transaction type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Philanthropic Donation" className="whitespace-normal leading-tight">
                        Philanthropic Donation <span className="text-xs text-[#8B949E]">(excluding tax advantages)</span>
                      </SelectItem>
                      <SelectItem value="Purchase" className="whitespace-normal">Purchase</SelectItem>
                      <SelectItem value="Fine" className="whitespace-normal">Fine</SelectItem>
                      <SelectItem value="Investment" className="whitespace-normal">Investment</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* STEP 4: Your Income */}
          <div className="p-4 border border-[#30363D] bg-[#161B22] rounded-lg">
            <div className="text-sm font-bold text-[#C9D1D9] mb-3">Step 4: Enter an annual income</div>
            <FormField
              control={form.control}
              name="userIncome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-[#8B949E] leading-tight">
                    Annual income (real or imagined)
                  </FormLabel>
                  <div className="mt-1 relative rounded-md">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-secondary-500">
                      {getCurrencySymbol(form.getValues().currency)}
                    </span>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder={form.getValues().currency === "USD" ? "58,389" : "28,217"}
                        className="pl-7"
                        inputMode="numeric"
                        onChange={(e) => handleNumberInputChange(e, field.onChange)}
                        onBlur={(e) => {
                          formatCurrencyInput(e);
                          field.onBlur();
                        }}
                      />
                    </FormControl>
                  </div>
                  <p className="mt-1 text-xs text-[#8B949E] leading-relaxed whitespace-normal">
                    {form.getValues().currency === "USD" 
                      ? "The average net annual salary in the US is ~$58,389." 
                      : "The average net annual salary within the EU is ~€28,217."} 
                    <br className="hidden sm:block"/>You can enter any amount - no need to share your actual income.
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-[#2F81F7] hover:bg-[#57A3F7] text-white font-bold shadow-lg transition-all"
            disabled={isLoading}
          >
            {isLoading ? "Calculating..." : "Calculate comparison"}
          </Button>
        </form>
      </Form>
    </section>
  );
}