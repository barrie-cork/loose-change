import { ShieldIcon } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function PrivacyNotice() {
  return (
    <Alert className="bg-[#0D1117] border border-[#30363D] mt-12 mb-6">
      <div className="flex items-start gap-3">
        <ShieldIcon className="h-5 w-5 text-[#2F81F7] mt-0.5" />
        <AlertDescription className="text-[#8B949E] leading-relaxed">
          <strong className="text-[#C9D1D9]">Privacy Notice:</strong> We do not store any personal data or income information. 
          All calculations are performed in your browser without sending income data to our servers. 
          See our <a href="https://github.com/barrie-cork/loose-change/discussions/1" target="_blank" rel="noopener noreferrer" className="text-[#2F81F7] hover:text-[#57A3F7] hover:underline transition-colors">methodology section</a> for 
          more details on how we handle data.
        </AlertDescription>
      </div>
    </Alert>
  );
}