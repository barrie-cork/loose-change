import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { ComparisonResult } from "@/types";
import { formatComparisonResult } from "@/lib/utils";

interface ResultsProps {
  result: ComparisonResult | null;
}

export default function Results({ result }: ResultsProps) {
  const formattedResult = useMemo(() => {
    if (!result) return null;
    return formatComparisonResult(result);
  }, [result]);

  if (!formattedResult) {
    return null;
  }

  const {
    billionaireName,
    transactionType,
    formattedTransactionAmount,
    formattedUserEquivalent,
    formattedUserIncome,
    formattedBillionaireNetWorth,
    formattedPercentOfIncome,
    contextDescription,
    timeDescription,
    currency,
    exchangeRate
  } = formattedResult;

  const shareText = encodeURIComponent(
    `${billionaireName} ${transactionType.toLowerCase()}ing ${formattedTransactionAmount} is like me ${transactionType.toLowerCase()}ing ${formattedUserEquivalent}! Find out what billionaire spending means for you at Loose Change.`
  );

  return (
    <section className="lg:col-span-7 bg-[#0D1117] rounded-lg shadow-xl border border-[#30363D] p-6">
      <h2 className="text-2xl font-bold text-[#C9D1D9] mb-6">Your wealth comparison</h2>

      <div className="space-y-6">
        {/* Results Summary */}
        <div className="p-4 bg-[#161B22] rounded-md border border-[#30363D] shadow-inner">
          <h3 className="text-lg font-medium text-[#C9D1D9] mb-2">
            {billionaireName} {transactionType.toLowerCase()}ing {formattedTransactionAmount} is like you {transactionType.toLowerCase()}ing{" "}
            <span className="font-bold text-[#2F81F7]">{formattedUserEquivalent}</span>
          </h3>
          <p className="text-[#C9D1D9]">
            Based on your annual income of {formattedUserIncome} compared to {billionaireName}'s net worth of {formattedBillionaireNetWorth}, this is what the equivalent spending would feel like.
          </p>
          <p className="text-xs text-[#8B949E] mt-1 italic">
            Note: Billionaire wealth data from Gapminder (2022) likely underestimates current net worth as most billionaires have increased their wealth since then.
          </p>
        </div>



        {/* Context Examples */}
        <div>
          <h3 className="text-sm font-bold text-[#C9D1D9] mb-2">To put this {formattedUserEquivalent} in context</h3>
          <ul className="space-y-2 text-sm text-[#C9D1D9]">
            <li className="flex items-start">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#2F81F7] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
              <span>{contextDescription}</span>
            </li>
            <li className="flex items-start">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#2F81F7] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
              <span>{timeDescription}</span>
            </li>
            <li className="flex items-start">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#2F81F7] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
              <span>This represents {formattedPercentOfIncome}% of your annual income.</span>
            </li>
            {currency !== "USD" && exchangeRate && (
              <li className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#2F81F7] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="16" x2="12" y2="12"></line>
                  <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                <span>All values shown in {currency}. Exchange rate: 1 USD = {exchangeRate.toFixed(4)} {currency}.</span>
              </li>
            )}
          </ul>
        </div>

        {/* Share Results */}
        <div>
          <h3 className="text-sm font-bold text-[#C9D1D9] mb-2">Share this comparison</h3>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              className="inline-flex items-center px-3 py-1.5 text-sm border-[#30363D] bg-[#21262D] text-[#C9D1D9] hover:bg-[#30363D]"
              onClick={() => window.open(`https://twitter.com/intent/tweet?text=${shareText}`, "_blank")}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1.5 text-[#1DA1F2]">
                <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
              </svg>
              Twitter
            </Button>
            <Button
              variant="outline"
              className="inline-flex items-center px-3 py-1.5 text-sm border-[#30363D] bg-[#21262D] text-[#C9D1D9] hover:bg-[#30363D]"
              onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${shareText}`, "_blank")}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1.5 text-[#4267B2]">
                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
              </svg>
              Facebook
            </Button>
            <Button
              variant="outline"
              className="inline-flex items-center px-3 py-1.5 text-sm border-[#30363D] bg-[#21262D] text-[#C9D1D9] hover:bg-[#30363D]"
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert("Link copied to clipboard!");
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1.5 text-[#2F81F7]">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
              </svg>
              Copy Link
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
