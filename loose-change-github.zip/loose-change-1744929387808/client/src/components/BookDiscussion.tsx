export default function BookDiscussion() {
  return (
    <a 
      href="https://www.reddit.com/r/AskAnthropology/s/hO12tZjT22" 
      target="_blank" 
      rel="noopener noreferrer"
      className="text-[#2F81F7] hover:text-[#57A3F7] transition-colors underline"
    >
      Reddit discussion on the book
    </a>
  );
}