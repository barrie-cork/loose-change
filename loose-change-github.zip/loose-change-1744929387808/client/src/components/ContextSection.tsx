import BookDiscussion from "./BookDiscussion";

export default function ContextSection() {
  return (
    <section id="how-it-works" className="mt-12 bg-[#0D1117] border border-[#30363D] rounded-lg p-6">
      <h2 className="text-xl font-semibold text-[#C9D1D9] mb-4">Understanding wealth disparity</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="space-y-2">
          <div className="bg-[#161B22] rounded-full w-12 h-12 flex items-center justify-center mb-3 border border-[#30363D]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#2F81F7]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
            </svg>
          </div>
          <h3 className="font-medium text-[#C9D1D9]">Relative perspective</h3>
          <p className="text-sm text-[#8B949E] leading-relaxed">
            What feels like a small amount to a billionaire could be life-changing for most people. This tool helps visualize that disparity.
          </p>
        </div>
        <div className="space-y-2">
          <div className="bg-[#161B22] rounded-full w-12 h-12 flex items-center justify-center mb-3 border border-[#30363D]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#2F81F7]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
            </svg>
          </div>
          <h3 className="font-medium text-[#C9D1D9]">Historical & updated data</h3>
          <p className="text-sm text-[#8B949E] leading-relaxed">
            Our calculations use billionaire net worth data from the Gapminder Billionaires dataset (2022).
          </p>
        </div>
        <div className="space-y-2">
          <div className="bg-[#161B22] rounded-full w-12 h-12 flex items-center justify-center mb-3 border border-[#30363D]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#2F81F7]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <h3 className="font-medium text-[#C9D1D9]">Financial literacy</h3>
          <p className="text-sm text-[#8B949E] leading-relaxed">
            This tool helps understand philanthropic donations (excluding tax write-off advantages) and regulatory fines by making billionaire financial actions relatable to everyday experiences.
          </p>
        </div>
        
        <div id="methodology" className="space-y-2">
          <div className="bg-[#161B22] rounded-full w-12 h-12 flex items-center justify-center mb-3 border border-[#30363D]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#2F81F7]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="font-medium text-[#C9D1D9]">Privacy & data security</h3>
          <p className="text-sm text-[#8B949E] leading-relaxed">
            All calculations are performed client-side in your browser. Your income and other financial information is never stored or transmitted to our servers. We employ a stateless architecture where sensitive inputs remain only in your local session.
          </p>
        </div>
      </div>
      
      <div className="mt-8 pt-6 border-t border-[#30363D] text-center">
        <h3 className="font-medium text-[#C9D1D9] mb-3">Inspired by</h3>
        <div className="max-w-2xl mx-auto text-left">
          <p className="text-sm text-[#8B949E] mb-4 leading-relaxed">
            This project was inspired in part by <a href="https://en.m.wikipedia.org/wiki/The_Dawn_of_Everything" target="_blank" rel="noopener noreferrer" className="text-[#2F81F7] hover:underline transition"><em>The Dawn of Everything</em> by David Graeber and David Wengrow</a>. A book that challenges me on how to think about inequality and human possibility.
          </p>
          <p className="text-sm text-[#8B949E] mb-4 leading-relaxed">
            Loose Change tried to echo one of their central themes: that economic systems are not fixed or inevitable but shaped by choices, power and imagination. By making wealth disparity tangible, we hope to encourage people to reflect not just on how the world is, but how it could be.
          </p>
        </div>
        <BookDiscussion />
      </div>
    </section>
  );
}
