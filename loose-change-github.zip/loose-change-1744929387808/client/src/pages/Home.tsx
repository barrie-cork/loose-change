import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import Calculator from "@/components/Calculator";
import Results from "@/components/Results";
import ContextSection from "@/components/ContextSection";
import FAQSection from "@/components/FAQSection";
import CodeContributionSection from "@/components/CodeContributionSection";
import { ComparisonResult } from "@/types";

export default function Home() {
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);

  const handleCalculationComplete = (result: ComparisonResult) => {
    setComparisonResult(result);
    
    // Scroll to results on mobile only
    setTimeout(() => {
      // Only scroll on mobile devices
      if (window.innerWidth < 1024) {
        const resultsSection = document.getElementById("results-section");
        if (resultsSection) {
          const offsetTop = resultsSection.offsetTop - 20;
          window.scrollTo({
            top: offsetTop,
            behavior: "smooth"
          });
        }
      }
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#111827]">
      <Header />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <HeroSection />
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <Calculator onCalculationComplete={handleCalculationComplete} />
          
          <div id="results-section" className={`lg:col-span-7 ${!comparisonResult ? 'hidden lg:block lg:invisible' : ''}`}>
            <Results result={comparisonResult} />
          </div>
        </div>
        
        <ContextSection />
        <FAQSection />
        <CodeContributionSection />
      </main>
      
      <Footer />
    </div>
  );
}
