export interface Billionaire {
  id: number;
  name: string;
  netWorth?: string | number;
  source?: string;
  imageUrl?: string;
  updatedAt?: string;
  // Adding snake_case versions to handle the database fields
  net_worth?: string | number;
  image_url?: string;
  updated_at?: string;
}

export interface ComparisonInput {
  billionaireId: number;
  customNetWorth?: number;
  transactionAmount: number;
  transactionType: string;
  userIncome: number;
  currency: Currency;
}

export type Currency = "USD" | "EUR";

export interface ComparisonResult {
  billionaireName: string;
  billionaireNetWorth: number;
  transactionAmount: number;
  transactionType: string;
  userIncome: number;
  userEquivalent: number;
  percentOfIncome: number;
  workHoursToEarn: number;
  currency: Currency;
  exchangeRate?: number;
}

export interface FormattedComparisonResult extends ComparisonResult {
  formattedUserEquivalent: string;
  formattedTransactionAmount: string;
  formattedBillionaireNetWorth: string;
  formattedUserIncome: string;
  formattedPercentOfIncome: string;
  contextDescription: string;
  timeDescription: string;
}
