import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { ComparisonResult, FormattedComparisonResult } from "@/types";

/**
 * Merges Tailwind classes
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats a number as currency with appropriate abbreviations
 */
export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: amount < 1 ? 2 : 0,
    maximumFractionDigits: amount < 10 ? 2 : 0
  }).format(amount);
}

/**
 * Formats large numbers with abbreviations (K, M, B)
 */
export function formatLargeNumber(num: number): string {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
  return num.toString();
}

/**
 * Parses a currency string into a number
 */
export function parseCurrencyInput(input: string): number {
  if (!input) return 0;
  return parseFloat(input.replace(/[$,]/g, ''));
}

/**
 * Gets a context description based on the user equivalent amount
 */
export function getContextDescription(amount: number): string {
  if (amount < 5) {
    return 'For you, this is less than the price of a coffee.';
  } else if (amount < 20) {
    return 'For you, this is about the price of a meal at a casual restaurant.';
  } else if (amount < 100) {
    return 'For you, this is like a nice dinner for two at a restaurant.';
  } else if (amount < 500) {
    return 'For you, this is a significant expense, like a major household purchase.';
  } else if (amount < 1000) {
    return 'For you, this is like a month of car payments or a small vacation.';
  } else {
    return 'For you, this is a major expense, similar to a month\'s rent or mortgage payment in many areas.';
  }
}

/**
 * Gets a time description based on work hours to earn
 */
export function getTimeDescription(hours: number): string {
  if (hours < 1) {
    return `It would take you about ${Math.round(hours * 60)} minutes of work to earn this amount.`;
  } else if (hours < 24) {
    return `It would take you about ${hours.toFixed(1)} hours of work to earn this amount.`;
  } else if (hours < 168) { // Less than a week
    return `It would take you about ${(hours / 24).toFixed(1)} days of work to earn this amount.`;
  } else if (hours < 720) { // Less than a month (30 days)
    return `It would take you about ${(hours / 168).toFixed(1)} weeks of work to earn this amount.`;
  } else if (hours < 8760) { // Less than a year
    return `It would take you about ${(hours / 720).toFixed(1)} months of work to earn this amount.`;
  } else {
    return `It would take you about ${(hours / 8760).toFixed(1)} years of work to earn this amount.`;
  }
}

/**
 * Formats a comparison result with all the necessary formatted values
 */
export function formatComparisonResult(result: ComparisonResult): FormattedComparisonResult {
  const currencyCode = result.currency || 'USD';
  
  return {
    ...result,
    formattedUserEquivalent: formatCurrency(result.userEquivalent, currencyCode),
    formattedTransactionAmount: formatCurrency(result.transactionAmount, currencyCode),
    formattedBillionaireNetWorth: formatCurrency(result.billionaireNetWorth, currencyCode),
    formattedUserIncome: formatCurrency(result.userIncome, currencyCode),
    formattedPercentOfIncome: result.percentOfIncome.toFixed(4),
    contextDescription: getContextDescription(result.userEquivalent),
    timeDescription: getTimeDescription(result.workHoursToEarn)
  };
}
