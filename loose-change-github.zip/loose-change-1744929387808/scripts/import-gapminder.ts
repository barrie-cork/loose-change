import { parse } from 'csv-parse/sync';
import fs from 'fs';
import path from 'path';
import { db, pool } from '../server/db';
import { billionaires } from '../shared/schema';
import { eq } from 'drizzle-orm';

const BILLIONAIRES_CSV_PATH = '/tmp/billionaires/ddf--entities--person.csv';
const WORTH_CSV_PATH = '/tmp/billionaires/ddf--datapoints--worth--by--person--time.csv';
const LATEST_YEAR = 2022; // Filter for latest year available

async function importGapminderData() {
  try {
    console.log('Starting Gapminder billionaires data import...');
    
    // Read and parse the billionaire information
    const billionairesCsvContent = fs.readFileSync(BILLIONAIRES_CSV_PATH, 'utf-8');
    const billionairesData = parse(billionairesCsvContent, {
      columns: true,
      skip_empty_lines: true
    });
    
    // Read and parse the wealth information
    const worthCsvContent = fs.readFileSync(WORTH_CSV_PATH, 'utf-8');
    const worthData = parse(worthCsvContent, {
      columns: true,
      skip_empty_lines: true
    });
    
    // Filter for only the latest year's worth data
    const latestWorthData = worthData.filter((d: any) => Number(d.time) === LATEST_YEAR);
    
    // Create a map of person ID to worth
    const personWorthMap = new Map();
    latestWorthData.forEach((d: any) => {
      personWorthMap.set(d.person, Number(d.worth));
    });
    
    // Clear existing data
    await db.delete(billionaires);
    console.log('Cleared existing billionaire data');
    
    // Prepare combined data
    const billionairesForImport = [];
    
    for (const person of billionairesData) {
      // Skip if we don't have worth data for this person
      if (!personWorthMap.has(person.person)) continue;
      
      // Get wealth in millions
      const worthInMillions = personWorthMap.get(person.person);
      
      // Convert to full number (in dollars)
      const netWorth = (worthInMillions * 1000000).toString();
      
      // Extract the primary source of wealth
      let source = '';
      if (person.source) {
        // Take first source before any delimiter
        source = person.source.split(';')[0].split(',')[0].trim();
      } else if (person.industry) {
        // Fallback to industry if source is not available
        source = person.industry.split(';')[0].split(',')[0].trim();
      }
      
      // Use the first name from the names column if available
      const name = person.name || person.names?.split(';')[0] || '';
      
      if (name && netWorth) {
        billionairesForImport.push({
          name,
          net_worth: netWorth,
          source,
          image_url: '',
          updated_at: new Date().toISOString()
        });
      }
    }
    
    console.log(`Prepared ${billionairesForImport.length} billionaires for import`);
    
    // Import data in batches to avoid hitting database limits
    const BATCH_SIZE = 100;
    let imported = 0;
    
    for (let i = 0; i < billionairesForImport.length; i += BATCH_SIZE) {
      const batch = billionairesForImport.slice(i, i + BATCH_SIZE);
      
      // Create placeholders for the batch
      const placeholders = batch.map((_, idx) => 
        `($${idx*5+1}, $${idx*5+2}, $${idx*5+3}, $${idx*5+4}, $${idx*5+5})`
      ).join(', ');
      
      // Create values array
      const values = batch.flatMap(b => 
        [b.name, b.net_worth, b.source, b.image_url, b.updated_at]
      );
      
      // Run the query
      const query = `
        INSERT INTO billionaires (name, net_worth, source, image_url, updated_at)
        VALUES ${placeholders}
      `;
      
      await db.$client.query(query, values);
      imported += batch.length;
      console.log(`Imported ${imported}/${billionairesForImport.length} billionaires`);
    }
    
    console.log('Gapminder billionaires data import completed successfully');
  } catch (error) {
    console.error('Error importing Gapminder data:', error);
  } finally {
    // Close the database connection
    await pool.end();
  }
}

// Run the import function
importGapminderData();