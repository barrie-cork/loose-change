import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";

// Required for Neon serverless
neonConfig.webSocketConstructor = ws;

async function main() {
  console.log("Pushing schema to database...");
  
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL not found");
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });

  try {
    console.log("Creating tables if they don't exist...");
    
    // Users table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      );
    `);
    
    // Billionaires table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS billionaires (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        net_worth NUMERIC NOT NULL,
        source TEXT,
        image_url TEXT,
        updated_at TEXT
      );
    `);
    
    console.log("Schema pushed successfully!");
  } catch (error) {
    console.error("Error pushing schema:", error);
    process.exit(1);
  }

  await pool.end();
}

main().catch(console.error);