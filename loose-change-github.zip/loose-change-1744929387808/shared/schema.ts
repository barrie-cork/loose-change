import { pgTable, text, serial, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema from the original file
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Billionaires schema
export const billionaires = pgTable("billionaires", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  netWorth: numeric("net_worth").notNull(),
  source: text("source"),
  imageUrl: text("image_url"),
  updatedAt: text("updated_at"),
});

export const insertBillionaireSchema = createInsertSchema(billionaires).pick({
  name: true,
  netWorth: true,
  source: true,
  imageUrl: true,
  updatedAt: true,
});

export type InsertBillionaire = z.infer<typeof insertBillionaireSchema>;
// Export extended type that includes both camelCase and snake_case properties
export type Billionaire = typeof billionaires.$inferSelect & {
  // Add snake_case aliases to support database field names
  net_worth?: string | number;
  image_url?: string;
  updated_at?: string;
};

// Validation schema for the comparison calculation
// Exchange rates schema
export const exchangeRates = pgTable("exchange_rates", {
  id: serial("id").primaryKey(),
  baseCurrency: text("base_currency").notNull(),
  targetCurrency: text("target_currency").notNull(),
  rate: numeric("rate").notNull(),
  lastUpdated: text("last_updated").notNull(),
});

export const insertExchangeRateSchema = createInsertSchema(exchangeRates).pick({
  baseCurrency: true,
  targetCurrency: true,
  rate: true,
  lastUpdated: true,
});

export type InsertExchangeRate = z.infer<typeof insertExchangeRateSchema>;
export type ExchangeRate = typeof exchangeRates.$inferSelect;

// Currency enum
export const Currency = {
  USD: "USD",
  EUR: "EUR",
} as const;

export type CurrencyType = typeof Currency[keyof typeof Currency];

export const comparisonSchema = z.object({
  billionaireId: z.number().positive(),
  customNetWorth: z.number().positive().optional(),
  transactionAmount: z.number().positive(),
  transactionType: z.enum(["Philanthropic Donation", "Purchase", "Fine", "Investment"]),
  userIncome: z.number().positive(),
  currency: z.enum([Currency.USD, Currency.EUR]).default(Currency.EUR),
});

export type ComparisonInput = z.infer<typeof comparisonSchema>;

// Comparison result schema
export const comparisonResultSchema = z.object({
  billionaireName: z.string(),
  billionaireNetWorth: z.number(),
  transactionAmount: z.number(),
  transactionType: z.string(),
  userIncome: z.number(),
  userEquivalent: z.number(),
  percentOfIncome: z.number(),
  workHoursToEarn: z.number(),
  currency: z.enum([Currency.USD, Currency.EUR]).default(Currency.EUR),
  exchangeRate: z.number().optional(),
});

export type ComparisonResult = z.infer<typeof comparisonResultSchema>;
