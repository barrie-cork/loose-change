# Contributing to Loose Change

Thank you for your interest in contributing to Loose Change! This document provides guidelines and instructions for contributing to this project.

## Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/barrie-cork/loose-change.git
   cd loose-change
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up the database**
   - Make sure PostgreSQL is installed and running
   - Create a `.env` file in the root directory with your database connection string:
     ```
     DATABASE_URL=postgres://username:password@localhost:5432/loose_change
     ```
   - Initialize the database:
     ```bash
     npm run db:push
     ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   - Navigate to `http://localhost:5000`

## Contribution Guidelines

### Code Style
- Follow the existing code style
- Use TypeScript for type safety
- Use meaningful variable and function names
- Add comments for complex logic

### Pull Request Process
1. Fork the repository
2. Create a new branch for your feature or bugfix
3. Make your changes
4. Ensure the application still works as expected
5. Submit a pull request with a clear description of the changes

### Areas for Contribution
- **UI/UX improvements**: Make the application more intuitive and user-friendly
- **Performance optimizations**: Identify and fix bottlenecks
- **New features**: Add new ways to visualize wealth comparisons
- **Data updates**: Help keep billionaire data current
- **Documentation**: Improve the README and code documentation
- **Translations**: Add support for additional languages

## Code of Conduct

Please be respectful and considerate of other contributors. We aim to foster an inclusive and welcoming community.

## Questions?

If you have any questions or need help with contributing, please open an issue in the repository.

Thank you for your contributions!