import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { 
  billionaires, 
  comparisonSchema, 
  type ComparisonResult, 
  type ExchangeRate, 
  Currency, 
  type CurrencyType 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Seed initial data on startup
  try {
    await storage.seedBillionaireData();
    console.log("Database seeded with initial billionaire data");
  } catch (error) {
    console.error("Error seeding database:", error);
  }

  // API endpoint to get all billionaires with pagination
  app.get("/api/billionaires", async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 100;
      const sortBy = (req.query.sortBy as string) || 'netWorth';
      const sortOrder = (req.query.sortOrder as 'asc' | 'desc') || 'desc';
      const search = (req.query.search as string) || '';
      
      const offset = (page - 1) * limit;
      
      const [billionaires, totalCount] = await Promise.all([
        storage.getAllBillionaires({ limit, offset, sortBy, sortOrder, search }),
        storage.countBillionaires(search)
      ]);
      
      const totalPages = Math.ceil(totalCount / limit);
      
      res.json({
        data: billionaires,
        meta: {
          currentPage: page,
          totalPages,
          totalCount,
          perPage: limit
        }
      });
    } catch (error) {
      console.error("Error fetching billionaires:", error);
      res.status(500).json({ message: "Failed to fetch billionaires" });
    }
  });

  // API endpoint to get a specific billionaire by ID
  app.get("/api/billionaires/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid billionaire ID" });
      }

      const billionaire = await storage.getBillionaire(id);
      if (!billionaire) {
        return res.status(404).json({ message: "Billionaire not found" });
      }

      res.json(billionaire);
    } catch (error) {
      console.error("Error fetching billionaire:", error);
      res.status(500).json({ message: "Failed to fetch billionaire" });
    }
  });

  // API endpoint to calculate the wealth comparison
  app.post("/api/calculate", async (req: Request, res: Response) => {
    try {
      // Validate the input data
      const validationResult = comparisonSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const validationError = fromZodError(validationResult.error);
        return res.status(400).json({ message: validationError.message });
      }
      
      const { billionaireId, customNetWorth, transactionAmount, transactionType, userIncome, currency = Currency.USD } = validationResult.data;
      
      // Get billionaire data
      const billionaire = await storage.getBillionaire(billionaireId);
      if (!billionaire) {
        return res.status(404).json({ message: "Billionaire not found" });
      }
      
      // Parse the netWorth value from string to number (handle both camelCase and snake_case)
      if (!billionaire.netWorth && !billionaire.net_worth && !customNetWorth) {
        return res.status(400).json({ message: "Billionaire net worth data not available" });
      }
      
      // Use custom net worth if provided, otherwise use the database value
      const billionaireNetWorth = customNetWorth || parseFloat((billionaire.netWorth || billionaire.net_worth || "0").toString());
      
      // Handle currency conversion if needed (Billionaire net worth is always in USD)
      let exchangeRate = 1;
      let convertedTransactionAmount = transactionAmount;
      let convertedUserIncome = userIncome;
      
      if (currency !== Currency.USD) {
        // Fetch the exchange rate (USD to selected currency)
        try {
          const exchangeRateData = await storage.fetchAndStoreExchangeRate(Currency.USD, currency);
          exchangeRate = parseFloat(exchangeRateData.rate.toString());
          
          // No need to convert amounts since we'll calculate everything in USD and then convert the result
        } catch (error) {
          console.error("Error fetching exchange rate:", error);
          // Continue with default exchange rate of 1
        }
      }
      
      // Calculate the proportion and equivalent amount (in USD)
      const billionaireRatio = transactionAmount / billionaireNetWorth;
      const userEquivalent = userIncome * billionaireRatio;
      
      // Calculate percentage of income
      const percentOfIncome = (userEquivalent / userIncome) * 100;
      
      // Calculate how many hours it would take to earn this amount
      const hourlyWage = userIncome / 2080; // Approximate working hours in a year (40 hours * 52 weeks)
      const workHoursToEarn = userEquivalent / hourlyWage;
      
      // Prepare the result
      const result: ComparisonResult = {
        billionaireName: billionaire.name,
        billionaireNetWorth,
        transactionAmount,
        transactionType,
        userIncome,
        userEquivalent,
        percentOfIncome,
        workHoursToEarn,
        currency,
        exchangeRate
      };
      
      res.json(result);
    } catch (error) {
      console.error("Error calculating comparison:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to calculate comparison" });
    }
  });

  // API endpoint to get exchange rate
  app.get("/api/exchange-rate", async (req: Request, res: Response) => {
    try {
      const baseCurrency = (req.query.from as CurrencyType) || Currency.USD;
      const targetCurrency = (req.query.to as CurrencyType) || Currency.EUR;
      
      // Validate that we're using supported currencies
      if (!Object.values(Currency).includes(baseCurrency as any) || 
          !Object.values(Currency).includes(targetCurrency as any)) {
        return res.status(400).json({ 
          message: "Invalid currency. Supported currencies are: " + Object.values(Currency).join(", ") 
        });
      }
      
      // Get or fetch the exchange rate
      const exchangeRate = await storage.fetchAndStoreExchangeRate(baseCurrency, targetCurrency);
      
      res.json({
        from: baseCurrency,
        to: targetCurrency,
        rate: parseFloat(exchangeRate.rate.toString()),
        lastUpdated: exchangeRate.lastUpdated
      });
    } catch (error) {
      console.error("Error fetching exchange rate:", error);
      res.status(500).json({ message: "Failed to fetch exchange rate" });
    }
  });
  
  // Endpoint to create and serve GitHub backup directly
  app.get("/api/download-backup", async (req: Request, res: Response) => {
    try {
      const execAsync = promisify(exec);
      const tempDir = path.join('/tmp', 'loose-change-' + Date.now());
      const backupPath = path.join('/tmp', 'loose-change-github.zip');
      
      // Create backup on demand
      console.log('Creating backup directory...');
      await execAsync(`mkdir -p ${tempDir}`);
      
      // Copy all project files including the updated UI components and latest code
      console.log('Copying project files...');
      await execAsync(`cp -r ./client ./server ./shared ./public ./.gitignore ./package.json ./README.md ./LICENSE ./CONTRIBUTING.md ./tsconfig.json ./vite.config.ts ./drizzle.config.ts ./postcss.config.js ./tailwind.config.ts ./theme.json ./scripts ${tempDir}/`);
      
      // Add a version file
      const versionContent = `Loose Change v1.0.0\nExported on: ${new Date().toISOString()}\nBuilt with Replit\n`;
      fs.writeFileSync(path.join(tempDir, 'VERSION.txt'), versionContent);
      
      console.log('Creating zip file...');
      await execAsync(`cd ${tempDir}/.. && zip -r loose-change-github.zip ${path.basename(tempDir)}`);
      
      if (!fs.existsSync(backupPath)) {
        return res.status(404).json({ message: "Failed to create backup file" });
      }
      
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename=loose-change-github.zip');
      
      const fileStream = fs.createReadStream(backupPath);
      fileStream.pipe(res);
    } catch (error) {
      console.error("Error serving backup file:", error);
      res.status(500).json({ message: "Failed to serve backup file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
