import { 
  billionaires, 
  type Billionaire, 
  type InsertBillionaire,
  users, 
  type User, 
  type InsertUser,
  exchangeRates,
  type ExchangeRate,
  type InsertExchangeRate,
  type CurrencyType
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, sql as dbSql, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllBillionaires(options?: { 
    limit?: number;
    offset?: number; 
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    search?: string;
  }): Promise<Billionaire[]>;
  countBillionaires(search?: string): Promise<number>;
  getBillionaire(id: number): Promise<Billionaire | undefined>;
  createBillionaire(billionaire: InsertBillionaire): Promise<Billionaire>;
  updateBillionaire(id: number, billionaire: Partial<InsertBillionaire>): Promise<Billionaire | undefined>;
  deleteBillionaire(id: number): Promise<boolean>;
  seedBillionaireData(): Promise<void>;
  
  // Exchange rate methods
  getExchangeRate(baseCurrency: CurrencyType, targetCurrency: CurrencyType): Promise<ExchangeRate | undefined>;
  fetchAndStoreExchangeRate(baseCurrency: CurrencyType, targetCurrency: CurrencyType): Promise<ExchangeRate>;
  updateExchangeRate(id: number, rate: number): Promise<ExchangeRate | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllBillionaires(options?: { 
    limit?: number;
    offset?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    search?: string;
  }): Promise<Billionaire[]> {
    const { 
      limit = 100, 
      offset = 0, 
      sortBy = 'netWorth', 
      sortOrder = 'desc',
      search = ''
    } = options || {};
    
    // If there's a search term, use ILIKE for case-insensitive search
    if (search.trim()) {
      const searchTerm = `%${search.trim().toLowerCase()}%`;
      const query = `
        SELECT * FROM billionaires 
        WHERE LOWER(name) LIKE $1 OR LOWER(source) LIKE $1
        ORDER BY ${sortBy === 'name' ? 'name' : 'net_worth'} ${sortOrder}
        LIMIT $2 OFFSET $3
      `;
      const { rows } = await db.$client.query(query, [searchTerm, limit, offset]);
      return rows;
    } else {
      // No search term, just use regular sorting
      if (sortBy === 'name') {
        const results = await db.select()
          .from(billionaires)
          .orderBy(sortOrder === 'asc' ? asc(billionaires.name) : desc(billionaires.name))
          .limit(limit)
          .offset(offset);
        return results;
      } else {
        // Default to sorting by netWorth
        const results = await db.select()
          .from(billionaires)
          .orderBy(sortOrder === 'asc' ? asc(billionaires.netWorth) : desc(billionaires.netWorth))
          .limit(limit)
          .offset(offset);
        return results;
      }
    }
  }

  async countBillionaires(search?: string): Promise<number> {
    try {
      if (search && search.trim()) {
        const searchTerm = `%${search.trim().toLowerCase()}%`;
        const query = `
          SELECT COUNT(*) as count FROM billionaires 
          WHERE LOWER(name) LIKE $1 OR LOWER(source) LIKE $1
        `;
        const { rows } = await db.$client.query(query, [searchTerm]);
        return parseInt(rows[0].count, 10);
      } else {
        const { rows } = await db.$client.query('SELECT COUNT(*) as count FROM billionaires');
        return parseInt(rows[0].count, 10);
      }
    } catch (error) {
      console.error('Error counting billionaires:', error);
      return 0;
    }
  }

  async getBillionaire(id: number): Promise<Billionaire | undefined> {
    const [billionaire] = await db.select().from(billionaires).where(eq(billionaires.id, id));
    return billionaire;
  }

  async createBillionaire(insertBillionaire: InsertBillionaire): Promise<Billionaire> {
    const [billionaire] = await db
      .insert(billionaires)
      .values(insertBillionaire)
      .returning();
    return billionaire;
  }

  async updateBillionaire(id: number, billionaireUpdate: Partial<InsertBillionaire>): Promise<Billionaire | undefined> {
    const [updatedBillionaire] = await db
      .update(billionaires)
      .set(billionaireUpdate)
      .where(eq(billionaires.id, id))
      .returning();
    return updatedBillionaire;
  }

  async deleteBillionaire(id: number): Promise<boolean> {
    const [deletedBillionaire] = await db
      .delete(billionaires)
      .where(eq(billionaires.id, id))
      .returning({ id: billionaires.id });
    return !!deletedBillionaire;
  }

  async seedBillionaireData(): Promise<void> {
    try {
      // Check if data already exists to avoid duplicates
      const { rows } = await db.$client.query('SELECT COUNT(*) as count FROM billionaires');
      const count = parseInt(rows[0].count, 10);
      
      if (count === 0) {
        const defaultBillionaires = [
          {
            name: "Elon Musk",
            net_worth: "203800000000",
            source: "Tesla, SpaceX, Twitter",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Jeff Bezos",
            net_worth: "184500000000",
            source: "Amazon",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Bill Gates",
            net_worth: "141700000000",
            source: "Microsoft",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Larry Ellison",
            net_worth: "137200000000",
            source: "Oracle",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Mark Zuckerberg",
            net_worth: "127300000000",
            source: "Facebook",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Warren Buffett",
            net_worth: "121700000000",
            source: "Berkshire Hathaway",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Larry Page",
            net_worth: "111300000000",
            source: "Google",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Sergey Brin",
            net_worth: "106800000000",
            source: "Google",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Steve Ballmer",
            net_worth: "101200000000",
            source: "Microsoft",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Bernard Arnault",
            net_worth: "233800000000",
            source: "LVMH",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          // Additional billionaires
          {
            name: "George Soros",
            net_worth: "8500000000",
            source: "Hedge funds",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Michael Bloomberg",
            net_worth: "94500000000",
            source: "Bloomberg LP",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Carlos Slim Helu",
            net_worth: "93000000000",
            source: "Telecom",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Gautam Adani",
            net_worth: "84000000000",
            source: "Infrastructure, commodities",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Mukesh Ambani",
            net_worth: "83400000000",
            source: "Diversified",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Jim Walton",
            net_worth: "74500000000",
            source: "Walmart",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Alice Walton",
            net_worth: "70100000000",
            source: "Walmart",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Rob Walton",
            net_worth: "69800000000",
            source: "Walmart",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Charles Koch",
            net_worth: "57000000000",
            source: "Koch Industries",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
          {
            name: "Julia Koch & family",
            net_worth: "57000000000",
            source: "Koch Industries",
            image_url: "",
            updated_at: new Date().toISOString(),
          },
        ];
        
        // Direct database insertion
        const placeholders = defaultBillionaires.map((_, i) => 
          `($${i*5+1}, $${i*5+2}, $${i*5+3}, $${i*5+4}, $${i*5+5})`
        ).join(', ');
        
        const values = defaultBillionaires.flatMap(b => 
          [b.name, b.net_worth, b.source, b.image_url, b.updated_at]
        );
        
        const query = `
          INSERT INTO billionaires (name, net_worth, source, image_url, updated_at)
          VALUES ${placeholders}
        `;
        
        await db.$client.query(query, values);
        console.log('Seeded billionaire data successfully');
      }
    } catch (error) {
      console.error('Error seeding billionaire data:', error);
    }
  }

  // Exchange rate methods
  async getExchangeRate(baseCurrency: CurrencyType, targetCurrency: CurrencyType): Promise<ExchangeRate | undefined> {
    try {
      // Always fetch fresh rates to ensure accuracy
      // We'll directly call fetchAndStoreExchangeRate to get fresh data
      return await this.fetchAndStoreExchangeRate(baseCurrency, targetCurrency);
    } catch (error) {
      console.error('Error getting exchange rate:', error);
      return undefined;
    }
  }
  
  async fetchAndStoreExchangeRate(baseCurrency: CurrencyType, targetCurrency: CurrencyType): Promise<ExchangeRate> {
    try {
      // Always fetch fresh rates from API - intentionally skipping cache
      console.log(`Fetching exchange rate from ${baseCurrency} to ${targetCurrency}...`);
      
      // Use the ExchangeRate-API for real-time exchange rates
      const response = await fetch(`https://v6.exchangerate-api.com/v6/open-access-key/latest/${baseCurrency}`);
      const data = await response.json();
      
      if (!response.ok || data.result !== "success" || !data.conversion_rates || !data.conversion_rates[targetCurrency]) {
        console.log("Primary API failed, trying backup API...");
        
        // Backup API - Open Exchange Rates API
        const backupResponse = await fetch(`https://open.er-api.com/v6/latest/${baseCurrency}`);
        const backupData = await backupResponse.json();
        
        if (!backupData.rates || !backupData.rates[targetCurrency]) {
          throw new Error(`Could not fetch exchange rate from ${baseCurrency} to ${targetCurrency}`);
        }
        
        var rate = backupData.rates[targetCurrency];
      } else {
        var rate = data.conversion_rates[targetCurrency];
      }
      
      console.log(`Got exchange rate: 1 ${baseCurrency} = ${rate} ${targetCurrency}`);
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      // Check if we need to update an existing record or create a new one
      const existingRateRecord = await db
        .select()
        .from(exchangeRates)
        .where(
          and(
            eq(exchangeRates.baseCurrency, baseCurrency),
            eq(exchangeRates.targetCurrency, targetCurrency)
          )
        );
      
      let exchangeRate: ExchangeRate;
      
      if (existingRateRecord.length > 0) {
        // Update existing record
        const [updatedRate] = await db
          .update(exchangeRates)
          .set({ 
            rate: rate.toString(), 
            lastUpdated: today 
          })
          .where(eq(exchangeRates.id, existingRateRecord[0].id))
          .returning();
        
        exchangeRate = updatedRate;
      } else {
        // Create new record
        const [newRate] = await db
          .insert(exchangeRates)
          .values({
            baseCurrency,
            targetCurrency,
            rate: rate.toString(),
            lastUpdated: today
          })
          .returning();
        
        exchangeRate = newRate;
      }
      
      return exchangeRate;
    } catch (error) {
      console.error('Error fetching/storing exchange rate:', error);
      // Fallback to a default exchange rate if API fails
      const today = new Date().toISOString().split('T')[0];
      let fallbackRate;
      
      if (baseCurrency === 'USD' && targetCurrency === 'EUR') {
        fallbackRate = 0.92; // Approximate USD to EUR rate
      } else if (baseCurrency === 'EUR' && targetCurrency === 'USD') {
        fallbackRate = 1.09; // Approximate EUR to USD rate
      } else {
        fallbackRate = 1.0; // Default to 1:1 if unknown
      }
      
      console.warn(`Using fallback exchange rate: 1 ${baseCurrency} = ${fallbackRate} ${targetCurrency}`);
      
      // Look for existing record to update
      const existingRateRecord = await db
        .select()
        .from(exchangeRates)
        .where(
          and(
            eq(exchangeRates.baseCurrency, baseCurrency),
            eq(exchangeRates.targetCurrency, targetCurrency)
          )
        );
      
      if (existingRateRecord.length > 0) {
        // Update existing record
        const [updatedRate] = await db
          .update(exchangeRates)
          .set({ 
            rate: fallbackRate.toString(), 
            lastUpdated: today 
          })
          .where(eq(exchangeRates.id, existingRateRecord[0].id))
          .returning();
        
        return updatedRate;
      } else {
        // Create new record
        const [newRate] = await db
          .insert(exchangeRates)
          .values({
            baseCurrency,
            targetCurrency,
            rate: fallbackRate.toString(),
            lastUpdated: today
          })
          .returning();
        
        return newRate;
      }
    }
  }
  
  async updateExchangeRate(id: number, rate: number): Promise<ExchangeRate | undefined> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const [updatedRate] = await db
        .update(exchangeRates)
        .set({ 
          rate: rate.toString(), 
          lastUpdated: today 
        })
        .where(eq(exchangeRates.id, id))
        .returning();
      
      return updatedRate;
    } catch (error) {
      console.error('Error updating exchange rate:', error);
      return undefined;
    }
  }
}

// Initialize database storage and seed with default data
export const storage = new DatabaseStorage();
